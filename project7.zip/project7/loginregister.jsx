import React from 'react';
import ReactDOM from 'react-dom';
import {
  Divider,
  List,
  ListItem,
  ListItemText,
  Typography,
  TextField
}
from '@material-ui/core';



import {
  HashRouter, Route, Switch, Link, Redirect
} from 'react-router-dom';

import { userInfo } from 'os';

import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import axios from 'axios';
import TopBar from './components/topBar/TopBar';
import UserDetail from './components/userDetail/UserDetail';
import UserList from './components/userList/UserList';
import UserPhotos from './components/userPhotos/UserPhotos';
import Login from './components/login/Login'
import Register from './components/register/Register'




function Swi(props) {
  const boole = props.boole;
  if (boole) {
    return <Login/>;
  }
  return <Register />;
}


function ExampleB(props) {
  return (
    <Button onClick={props.onClick}>
      Go to Login
    </Button>
  );
}

function Stateb(props) {
  return (
    <Button onClick={props.onClick}>
      Go to Register
    </Button>
  );
}

class Switche extends React.Component {
  constructor(props) {
    super(props);
    this.handleStateClick = this.handleStateClick.bind(this);
    this.handleExampleClick = this.handleExampleClick.bind(this);
    this.state = {boole: false};

   {(localStorage.getItem('_id'))?
     window.location.href = "http://localhost:3000/photo-share.html#/":console.log("newtreegui")}
  }

  handleStateClick() {
    this.setState({boole: true});
  }

  handleExampleClick() {
    this.setState({boole: false});
  }

  render() {
    const boole = this.state.boole;
    let button;

    if (boole) {
      button = <Stateb onClick={this.handleExampleClick} />;
    } else {
      button = <ExampleB onClick={this.handleStateClick} />;
    }

    return (
      <div>
        {button}
        <Swi boole={boole} />
      </div>
    );
  }
}

ReactDOM.render(
    <Switche />,
    document.getElementById('loginregister'),
  );
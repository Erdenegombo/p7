import React from 'react';
import {
  AppBar, Toolbar, Typography,
  Divider,
  List,
  ListItem,
  ListItemText,
  Avatar,
  Button
} from '@material-ui/core';
import './TopBar.css';
import axios from 'axios';

import {
  HashRouter, Route, Switch, Link
} from 'react-router-dom';



/**
 * Define TopBar, a React componment of CS142 project #5
 */
class TopBar extends React.Component {
  constructor(props) {
    super(props);
    this.state={page:"",
    name:"",
    listItems123: [],
    images: [],
  } 
    this.handleSubmit = this.handleSubmit.bind(this);
    this.fileInput = React.createRef();
  }



  onImageChange = event => {
    console.log(event.target.files);

    this.setState({
      images: event.target.files,
    });
  };

  onSubmit = e => {
    e.preventDefault();

    const formData = new FormData();

    Array.from(this.state.images).forEach(image => {
      formData.append('files', image);
    });

    axios
      .post(`http://localhost:1337/photos/new`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        user_id: localStorage.getItem('_id'),
      })
      .then(res => {
        console.log(res);
      })
      .catch(err => {
        console.log(err);
      });
  };

  login(){
    window.location.href = "http://localhost:3000/loginregister.html#/";
    localStorage.removeItem('username');
    localStorage.removeItem('_id');

  }

  handleSubmit(event) {
    event.preventDefault();
    alert(
      `Selected file - ${
        this.fileInput.current.files[0].name
      }`
    );
  }

      //this function is called when user presses the update button
  handleSubmit = (e) => {
    console.log(this.fileInput.current.files[0])
       e.preventDefault();
  
    //console.log(this.fileInput);
        // Create a DOM form and add the file to it under the name uploadedphoto
        const domForm = new FormData();
        domForm.append('uploadedphoto', this.fileInput.current.files[0]);
        axios.post('/photos/new', domForm ,
        {user_id :localStorage.getItem('_id')})
          .then((res) => {
            console.log(res);
          })
          .catch(err => console.log(`POST ERR: ${err}`));
  }


  render() {
    var name;
    var page;
    
    if(window.location.href.slice(40, 45) === "users"){
      //name = window.cs142models.userModel(window.location.href.slice(46, 70)).first_name;


      
      axios.get('http://localhost:3000/user/'+window.location.href.slice(46, 70))
      .then((response) => {
        this.setState({listItems123: response.data[0]})
      })
     .catch((error)=>{
        console.log(error);
     });



      name = this.state.listItems123.first_name;


      page ="User detail of ";
    }else if(window.location.href.slice(40, 45) === "photo"){
      //name = window.cs142models.userModel(window.location.href.slice(47, 71)).first_name;
  
      axios.get('http://localhost:3000/user/'+window.location.href.slice(47, 71))
      .then((response) => {
        this.setState({listItems123: response.data[0]})
      })
     .catch((error)=>{
        console.log(error);
     });

     

    name = this.state.listItems123.first_name;


      page ="Photos of  ";
    }else{
      page = "Welcome " + localStorage.getItem('username')
      name = "";
    }
    

    return (
      <AppBar className="cs142-topbar-appBar" position="absolute">
        <Toolbar>
          <Typography variant="h5" color="inherit">
              Munkh
          </Typography>

        <form onSubmit={this.handleSubmit}>
          <label>
            <input type="file" ref={this.fileInput} />
          </label>
          <br />
          <button type="submit">Submit</button>
        </form>

          <h2>{page + " " + name}</h2>
        </Toolbar>
        <Button variant="contained" color="primary" onClick={this.login} >
                  Sign Out
            </Button >
      </AppBar>
    );
  }
}

export default TopBar;

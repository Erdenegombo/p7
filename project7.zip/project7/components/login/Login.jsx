import React from 'react';
import ReactDOM from 'react-dom';
import {
  Divider,
  List,
  ListItem,
  ListItemText,
  Typography,
  TextField
}
from '@material-ui/core';



import {
  HashRouter, Route, Switch, Link, Redirect
} from 'react-router-dom';

import { userInfo } from 'os';

import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import axios from 'axios';





class Login extends React.Component {
constructor(props){
  super(props);
  this.state={
  username:'',
  password:'',
  first_name:'',
  last_name: '',
  location:'',
  description:'',
  occupation:'',
  }

  this.login = this.login.bind(this)

 }

 handleChangeUser(event) {
  this.setState({username: event.target.value})
}

handleChangePass(event) {
  this.setState({password: event.target.value})
}

handleChangeFName(event) {
  this.setState({first_name: event.target.value})
}

handleChangeLName(event) {
  this.setState({last_name: event.target.value})
}
handleChangeLoc(event) {
  this.setState({location: event.target.value})
}

handleChangeDes(event) {
  this.setState({description: event.target.value})
}

handleChangeOcc(event) {
  this.setState({occupation: event.target.value})
}



login(){
  
  axios.post('http://localhost:3000/admin/login', {
    login_name: this.state.username,
    password: this.state.password
  })
  .then(function (response) {
    console.log(response);
    localStorage.setItem('username', response.data.login_name);
    localStorage.setItem('_id', response.data._id);
    window.location.href = "http://localhost:3000/photo-share.html#/";
  })
  .catch((error)=>{
    this.setState({error: error.request.response})
    console.log(error.request.response)
 });
  
}





render() {
  return (
      <Card>  

        <Card align='center'>
          <CardContent>
            <Typography >Login : </Typography>
            <div><TextField id="standard-basic" label="Login-name" value={this.state.username} onChange={this.handleChangeUser.bind(this)}/></div>
            <div><TextField id="standard-basic" label="Password" value={this.state.password} onChange={this.handleChangePass.bind(this)}  /></div>
            <Button variant="contained" color="primary" onClick={this.login} >
                  Submit
            </Button >
            <Typography> {this.state.error}</Typography>
          </CardContent>

      </Card>
    </Card>
    )
  }
}


export default Login;

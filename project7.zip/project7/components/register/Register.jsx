import React from 'react';
import ReactDOM from 'react-dom';
import {
  Divider,
  List,
  ListItem,
  ListItemText,
  Typography,
  TextField
}
from '@material-ui/core';



import {
  HashRouter, Route, Switch, Link, Redirect
} from 'react-router-dom';

import { userInfo } from 'os';

import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import axios from 'axios';




class Register extends React.Component {
constructor(props){
  super(props);
  this.state={
  username:'',
  password:'',
  first_name:'',
  last_name: '',
  location:'',
  description:'',
  occupation:'',
  error : ''
  }

  this.register = this.register.bind(this)




 }

 handleChangeUser(event) {
  this.setState({username: event.target.value})
}

handleChangePass(event) {
  this.setState({password: event.target.value})
}

handleChangeFName(event) {
  this.setState({first_name: event.target.value})
}

handleChangeLName(event) {
  this.setState({last_name: event.target.value})
}
handleChangeLoc(event) {
  this.setState({location: event.target.value})
}

handleChangeDes(event) {
  this.setState({description: event.target.value})
}

handleChangeOcc(event) {
  this.setState({occupation: event.target.value})
}




register(){
  axios.post('http://localhost:3000/user/', {
    login_name: this.state.username,
    password: this.state.password,
    first_name: this.state.first_name,
    last_name: this.state.last_name,
    location: this.state.location,
    description: this.state.description,
    occupation: this.state.occupation,

  })
  .then(function (response) {
    console.log(response);
    localStorage.setItem('username', response.data.login_name);
    localStorage.setItem('_id', response.data._id);
    window.location.href = "http://localhost:3000/photo-share.html#/";
  }) 
  .catch((error)=>{
    this.setState({error: error.request.response})
    console.log(error.request.response)
 });

}





render() {
  return (
      <Card align='center' >  
        {  (localStorage.getItem('_id'))?
            window.location.href = "http://localhost:3000/photo-share.html#/":console.log("newtreegui")}
        <Card>
          <CardContent>
            <Typography >Register : </Typography>
            <div><TextField id="standard-basic" label="Login-name" value={this.state.username} onChange={this.handleChangeUser.bind(this)}/></div>
            <div> <TextField id="standard-basic" label="Password" value={this.state.password} onChange={this.handleChangePass.bind(this)}/></div>
            <div> <TextField id="standard-basic" label="First name" value={this.state.first_name} onChange={this.handleChangeFName.bind(this)}/></div>
            <div> <TextField id="standard-basic" label="Last name" value={this.state.last_name} onChange={this.handleChangeLName.bind(this)}/></div>
            <div> <TextField id="standard-basic" label="Location" value={this.state.location} onChange={this.handleChangeLoc.bind(this)}/></div>
            <div><TextField id="standard-basic" label="Description" value={this.state.description} onChange={this.handleChangeDes.bind(this)}/></div>
            <div> <TextField id="standard-basic" label="Occupation" value={this.state.occupation} onChange={this.handleChangeOcc.bind(this)}/></div>
      
            <Typography> {this.state.error}</Typography>
            <Button variant="contained" color="primary" onClick={this.register}  >
                  Submit
            </Button >
          </CardContent>
      </Card>
    </Card>
    )
  }
}

export default Register;

import React from 'react';
import {
  Divider,
  List,
  ListItem,
  ListItemText,
  Typography,
  Avatar 
}
from '@material-ui/core';

import {
  HashRouter, Route, Switch, Link
} from 'react-router-dom';

import axios from 'axios';
import './userList.css';
import { userInfo } from 'os';
import fetchModel from '../../lib/fetchModelData'

/**
 * Define UserList, a React componment of CS142 project #5
 */


class UserList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      listItem123: [],
      PCount: 0,
      listItem: []
    }

    axios.get('http://localhost:3000/user/list')
    .then(response => this.setState({ listItem123: response.data }));

    console.log(localStorage.getItem("_id"))
    
  }


  getCount(id)
  { 
      axios.get('http://localhost:3000/photosOfUser/'+id)
      .then((response) => {
      this.setState({listItem: response.data})
      })
  }


  outOfBandJSX (){  
    var listOfnames = this.state.listItem123.map((name) =>

    <Link to={"/users/" + name._id} key = {name._id} style={{ textDecoration: 'none' }}>
      <ListItem>
        <ListItemText  primary = {name.first_name + " " + name.last_name} />
      </ListItem>
  
      </Link>
    );
    
    return listOfnames; 
  }



  render() {
    return (
      <div>
        <Typography variant="body1">
          User list:
        </Typography>
         
        <List component="nav">
          {this.outOfBandJSX()}
        </List>
      </div>
    );
  }
}

export default UserList;

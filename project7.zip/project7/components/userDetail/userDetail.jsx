import React from 'react';
import {
  Typography
} from '@material-ui/core';

import {
  HashRouter, Route, Switch, Link
} from 'react-router-dom';

import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import fetchModel from '../../lib/fetchModelData'

import axios from 'axios';
import './userDetail.css';



/**
 * Define UserDetail, a React componment of CS142 project #5
 * {this.props.match.params.userId}
 * window.cs142models.userModel(userId)
 */
class UserDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      listItems123: [],
    }
    
   
    
    
  }

  detailer(){

  


    axios.get('http://localhost:3000/user/'+this.props.match.params.userId)
     .then((response) => {
       this.setState({listItems123: response.data[0]})
     })
    .catch((error)=>{
       console.log(error);
    });




    
    
    var listItems = this.state.listItems123;
    return(
      <div>
        <Typography color="default" variant="title" align="center">User Detail</Typography>
        <Typography color="default" variant="h6" >Name :  {listItems.first_name + " "+ listItems.last_name}</Typography>
        <Typography color="default" variant="h6" >Location : {listItems.location}</Typography>
        <Typography color="default" variant="h6" >Description : {listItems.description}</Typography>
        <Typography color="default" variant="h6" >Occupation : {listItems.occupation}</Typography>
        
        <Link to={"/photos/" +  this.props.match.params.userId}> 
          
          <Button variant="outlined" color="primary">
            Photos
          </Button>
        </Link>
      </div>
    )}



  render() {
    return(
     <div> 
       
       {this.detailer()}

     </div>
    )
  }
}

export default UserDetail;
